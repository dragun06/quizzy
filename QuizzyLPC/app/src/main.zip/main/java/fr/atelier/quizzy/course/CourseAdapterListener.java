package fr.atelier.quizzy.course;

public interface CourseAdapterListener {
    public void onClickCourse(Course item);
}
