package fr.atelier.quizzy.question;

public interface QuestionAdapterListener {
    void onFocusQuestion(int question, String answer);
}
